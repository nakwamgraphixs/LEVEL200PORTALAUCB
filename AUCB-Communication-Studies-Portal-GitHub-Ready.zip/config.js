/*
  AUCB Communication Studies Portal configuration

  IMPORTANT:
  Keep this file free of passwords, private API keys, or Google account credentials.

  Option A (recommended for a simple public portal):
  Publish a Google Sheet to the web as CSV and paste the CSV URL below.

  Example:
  SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID/export?format=csv&gid=0"

  The sheet should have a header row. Recommended columns:
  Index Number, Name, Programme, Level

  Phone numbers are intentionally NOT displayed by the public portal.
*/

const CONFIG = {
  SHEET_CSV_URL: "",

  // Optional Google Form URL for reporting incorrect records.
  REPORT_FORM_URL: "",

  // These are the fields the public portal can display.
  DISPLAY_FIELDS: [
    { key: "Index Number", label: "Index Number" },
    { key: "Name", label: "Full Name" },
    { key: "Programme", label: "Programme" },
    { key: "Level", label: "Level" }
  ]
};
