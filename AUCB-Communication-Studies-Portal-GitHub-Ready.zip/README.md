# AUCB Communication Studies Student Portal

GitHub-ready static website for the **African University of Communications and Business (AUCB), Kojo Yankah School of Communication Studies**.

## Features

- Search by student index number
- Reads student records from a Google Sheet CSV
- Shows only selected public fields
- Requires the student to confirm details before printing
- Clean print layout
- Report Wrong Details button
- Mobile-friendly design
- No server or database hosting required
- Suitable for GitHub Pages

## 1. Prepare the Google Sheet

Use row 1 as the column headings.

Recommended:

| Index Number | Name | Programme | Level | Phone |
|---|---|---|---|---|
| AUCS01260051 | LAWRENCE KWAME ANTWI | Communication Studies |  | 0269137401 |

**Important:** the public website is configured not to display the Phone column. Because phone numbers are personal information, consider keeping that column private.

The minimum required column is:

`Index Number`

## 2. Publish the sheet as CSV

For a simple public portal:

1. Open your Google Sheet.
2. Choose **File → Share → Publish to web**.
3. Select the correct sheet/tab.
4. Choose CSV if Google gives you a format option.
5. Publish it.
6. Copy the published CSV URL.

Another common CSV export format is:

`https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID/export?format=csv&gid=0`

Replace `YOUR_SHEET_ID` with your Sheet ID.

### Privacy warning

A publicly published CSV can potentially be accessed by anyone who has the URL and may expose the entire published sheet. Do **not** publish sensitive information.

For a stronger privacy setup, use a Google Apps Script web endpoint that returns only the requested student record rather than publishing the complete student list.

## 3. Connect the website

Open `config.js` and change:

```js
SHEET_CSV_URL: "",
```

to:

```js
SHEET_CSV_URL: "YOUR_PUBLISHED_CSV_URL",
```

Optional reporting form:

```js
REPORT_FORM_URL: "YOUR_GOOGLE_FORM_URL",
```

If you do not have a reporting form yet, leave it empty.

## 4. Test locally

Open `index.html` in a browser.

Some browsers restrict `fetch()` requests when opening HTML directly from a file. If that happens, use a small local server or test after deploying to GitHub Pages.

## 5. Upload to GitHub

Create a new GitHub repository, for example:

`aucb-communication-studies-portal`

Upload:

- `index.html`
- `style.css`
- `script.js`
- `config.js`
- `README.md`

Then go to:

**Repository → Settings → Pages**

Under deployment, choose:

- Source: **Deploy from a branch**
- Branch: **main**
- Folder: **/ (root)**

Save.

GitHub will provide your public Pages address.

## 6. Updating student records

Once connected to Google Sheets, you do **not** need to edit the website every time a student record changes.

Update the Google Sheet instead.

The portal fetches the current CSV when a search is performed.

## Recommended Google Sheet structure

For the public portal:

| Index Number | Name | Programme | Level |
|---|---|---|---|
| AUCS01260051 | LAWRENCE KWAME ANTWI | Communication Studies | 200 |

For administration, you can maintain additional private columns such as:

- Phone
- Email
- Status
- Notes

Do not expose unnecessary personal information through the public website.

## Optional next improvements

- Student photo
- Student ID card generation
- QR code on printed records
- Google Form for corrections
- Admin dashboard
- Search by name
- Department/course options
- Printable confirmation slip
- Verification code
- Google Apps Script API for better privacy
