const form = document.getElementById("searchForm");
const input = document.getElementById("indexNumber");
const statusBox = document.getElementById("status");
const resultSection = document.getElementById("resultSection");
const studentDetails = document.getElementById("studentDetails");
const confirmDetails = document.getElementById("confirmDetails");
const printBtn = document.getElementById("printBtn");
const reportBtn = document.getElementById("reportBtn");

let records = [];

document.addEventListener("DOMContentLoaded", () => {
  if (CONFIG.REPORT_FORM_URL) {
    reportBtn.href = CONFIG.REPORT_FORM_URL;
  } else {
    reportBtn.addEventListener("click", (event) => {
      event.preventDefault();
      showStatus("The reporting form has not been connected yet. Please contact the school office.", "error");
    });
  }

  form.addEventListener("submit", handleSearch);
  printBtn.addEventListener("click", handlePrint);
});

function normalize(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "");
}

async function handleSearch(event) {
  event.preventDefault();

  const index = input.value.trim();

  if (!index) {
    showStatus("Please enter your index number.", "error");
    hideResults();
    input.focus();
    return;
  }

  try {
    showStatus("Loading student records…", "info");
    hideResults();

    await loadRecords();

    const found = records.find(record =>
      normalize(record["Index Number"]) === normalize(index)
    );

    if (!found) {
      showStatus(
        "No student record was found for that index number. Check the number and try again.",
        "error"
      );
      return;
    }

    renderStudent(found);
    clearStatus();
  } catch (error) {
    console.error(error);
    showStatus(
      "The student database could not be loaded. Please check the Google Sheet connection.",
      "error"
    );
  }
}

async function loadRecords() {
  if (!CONFIG.SHEET_CSV_URL) {
    throw new Error("Google Sheet CSV URL is not configured.");
  }

  const response = await fetch(CONFIG.SHEET_CSV_URL, {
    cache: "no-store"
  });

  if (!response.ok) {
    throw new Error(`Database request failed: ${response.status}`);
  }

  const csv = await response.text();
  records = parseCSV(csv);

  if (!records.length) {
    throw new Error("No records found in the Google Sheet.");
  }

  const hasIndex = Object.keys(records[0]).some(key =>
    normalize(key) === normalize("Index Number")
  );

  if (!hasIndex) {
    throw new Error('The Google Sheet must contain a column named "Index Number".');
  }
}

function renderStudent(record) {
  studentDetails.innerHTML = "";

  CONFIG.DISPLAY_FIELDS.forEach(field => {
    const actualKey = Object.keys(record).find(
      key => normalize(key) === normalize(field.key)
    );

    const value = actualKey ? String(record[actualKey] ?? "").trim() : "";

    if (!value) return;

    const item = document.createElement("div");
    item.className = "detail-item";

    const label = document.createElement("span");
    label.className = "detail-label";
    label.textContent = field.label;

    const valueElement = document.createElement("span");
    valueElement.className = "detail-value";
    valueElement.textContent = value;

    item.append(label, valueElement);
    studentDetails.appendChild(item);
  });

  confirmDetails.checked = false;
  resultSection.classList.remove("hidden");
  resultSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function handlePrint() {
  if (!confirmDetails.checked) {
    showStatus("Please confirm that you have checked the details before printing.", "error");
    confirmDetails.focus();
    return;
  }

  clearStatus();
  window.print();
}

function hideResults() {
  resultSection.classList.add("hidden");
  studentDetails.innerHTML = "";
  confirmDetails.checked = false;
}

function showStatus(message, type) {
  statusBox.textContent = message;
  statusBox.className = `status ${type}`;
  statusBox.classList.remove("hidden");
}

function clearStatus() {
  statusBox.textContent = "";
  statusBox.className = "status hidden";
}

/*
  Small CSV parser.
  Handles quoted cells, commas inside quotes, and double quotes escaped as "".
*/
function parseCSV(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];

    if (char === '"' && quoted && next === '"') {
      cell += '"';
      i++;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") i++;
      row.push(cell);
      cell = "";

      if (row.some(value => value.trim() !== "")) {
        rows.push(row);
      }

      row = [];
    } else {
      cell += char;
    }
  }

  if (cell !== "" || row.length) {
    row.push(cell);
    if (row.some(value => value.trim() !== "")) rows.push(row);
  }

  if (!rows.length) return [];

  const headers = rows[0].map(header => header.trim());

  return rows.slice(1).map(values => {
    const record = {};
    headers.forEach((header, index) => {
      record[header] = (values[index] ?? "").trim();
    });
    return record;
  });
}
